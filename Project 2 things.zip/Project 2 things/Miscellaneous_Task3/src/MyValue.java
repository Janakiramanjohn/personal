import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	Text ww,tstatus;
	
	public MyValue(){
		this.ww = new Text();
		this.tstatus=new Text();
	}
	public MyValue(Text ww,Text tstatus){
		this.ww = ww;
		this.tstatus=tstatus;
	};
	
	

	@Override
	public void readFields(DataInput arg0) throws IOException {
		ww.readFields(arg0);
		tstatus.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		ww.write(arg0);
		tstatus.write(arg0);
	}
	
	public void setww(Text ww){
		this.ww=ww;
	}
	public void setStatus(Text tstatus){
		this.tstatus=tstatus;
	}
	public int getAmt(){
		return Integer.parseInt(ww.toString());
	}

	public String getStatus(){
		return tstatus.toString();
	}
}