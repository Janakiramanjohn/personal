import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class MyKey implements WritableComparable {
	Text citizen;
	
	public MyKey(){
		this.citizen = new Text();
	}
	public MyKey(Text citizen){
		this.citizen = citizen;		
	}
	@Override
	public void readFields(DataInput arg0) throws IOException {
		citizen.readFields(arg0);		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
	    citizen.write(arg0);
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public void setCitizen(Text citizen){
		this.citizen=citizen;
	}
	
	
	public String getCitizen() {
		return citizen.toString();
	}
	
	

}
