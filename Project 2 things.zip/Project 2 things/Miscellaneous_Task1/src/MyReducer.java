

import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<Text,Text, Text, Text> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal,Context c ) throws IOException, InterruptedException{
		int count1=0,count2=0;
		String data=null;
		//String g1=null,g2=null;
		for(Text each:rInpVal){
			data=each.toString();
			int w=Integer.parseInt(data);
	        
	        if(w==0){
	        	count2++;	
	        }
	        
	        /*if(data.equals("A"))
	        	count++;
	        if(data.equals("B"))
	        	count++;
	        if(data.equals("B-"))
	        	count++;
	        if(data.equals("C"))
	        	count++;
	        if(data.equals("D"))
	        	count++;
	        if(data.equals("E"))
	        	count++;
	        c.write(new Text(data.toString()),new Text(""+count+""));*/
		}
		c.write(new Text(rInpKey),new Text(" "+count2));
		
		
	}

}
